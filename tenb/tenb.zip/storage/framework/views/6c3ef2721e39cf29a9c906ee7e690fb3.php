<?php echo e($slot); ?>

<?php /**PATH E:\laragon\www\ujikom\SITENB-V2\tenb\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>