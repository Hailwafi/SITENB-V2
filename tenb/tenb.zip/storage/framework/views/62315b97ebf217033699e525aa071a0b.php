<!DOCTYPE html>
<html>
<head>
    <title>Kode Tiket Anda</title>
</head>
<body>
    <h1>Halo, <?php echo e($ticket->nama_lengkap); ?></h1>
    <p>Terima kasih telah membuat tiket. Berikut adalah detail tiket Anda:</p>
    <ul>
        <li>Kode Tiket: <strong><?php echo e($ticket->kode_tiket); ?></strong></li>
        <li>Token Tiket: <strong><?php echo e($ticket->token_tiket); ?></strong></li>
        <li>Kategori: <?php echo e($ticket->kategori); ?></li>
        <li>Sub Kategori: <?php echo e($ticket->sub_kategori); ?></li>
        <li>Jenis Tiket: <?php echo e($ticket->jenis_tiket); ?></li>
        <li>Deskripsi: <?php echo e($ticket->deskripsi); ?></li>
    </ul>
    <p>Silakan gunakan kode tiket ini untuk memeriksa status tiket Anda di platform kami.</p>
</body>
</html>
<?php /**PATH E:\laragon\www\ujikom\SITENB-V2\tenb\resources\views/emails/ticket_code.blade.php ENDPATH**/ ?>